import { Code, Database, Smartphone, Server } from "lucide-react";

export default function SkillsOverview() {
  const skills = [
    {
      icon: <Server className="text-xl" />,
      title: "Backend Development",
      description: "Node.js, Java Spring Boot, Python, PHP"
    },
    {
      icon: <Code className="text-xl" />,
      title: "Frontend Development", 
      description: "React, HTML5, CSS3, JavaScript ES6+"
    },
    {
      icon: <Database className="text-xl" />,
      title: "Database Management",
      description: "MongoDB, MySQL, PostgreSQL"
    },
    {
      icon: <Smartphone className="text-xl" />,
      title: "Mobile Development",
      description: "Swift, iOS Development, React Native"
    }
  ];

  return (
    <section className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4" data-testid="text-skills-title">
            Technical Expertise
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto" data-testid="text-skills-description">
            Proficient in modern technologies and frameworks for end-to-end development
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <div 
              key={index}
              className="bg-background p-6 rounded-lg card-hover smooth-transition"
              data-testid={`card-skill-${index}`}
            >
              <div className="primary-with-code w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                {skill.icon}
              </div>
              <h3 className="font-semibold mb-2" data-testid={`text-skill-title-${index}`}>
                {skill.title}
              </h3>
              <p className="text-muted-foreground text-sm" data-testid={`text-skill-description-${index}`}>
                {skill.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
