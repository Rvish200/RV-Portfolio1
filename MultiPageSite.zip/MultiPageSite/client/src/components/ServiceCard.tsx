import { ReactNode } from "react";

interface ServiceCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  features: string[];
  index: number;
}

export default function ServiceCard({ 
  icon, 
  title, 
  description, 
  features, 
  index 
}: ServiceCardProps) {
  return (
    <div 
      className="bg-background p-8 rounded-lg card-hover smooth-transition"
      data-testid={`card-service-${index}`}
    >
      <div className="primary-with-code w-16 h-16 rounded-lg flex items-center justify-center mb-6">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-4" data-testid={`text-service-title-${index}`}>
        {title}
      </h3>
      <p className="text-muted-foreground mb-6" data-testid={`text-service-description-${index}`}>
        {description}
      </p>
      <ul className="text-sm space-y-2">
        {features.map((feature, featureIndex) => (
          <li 
            key={featureIndex}
            className="flex items-center"
            data-testid={`text-service-feature-${index}-${featureIndex}`}
          >
            <i className="fas fa-check text-primary mr-2"></i>
            {feature}
          </li>
        ))}
      </ul>
    </div>
  );
}
