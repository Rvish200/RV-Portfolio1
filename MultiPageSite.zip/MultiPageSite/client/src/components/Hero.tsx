import { Link } from "wouter";
import ImageSlider from "./ImageSlider";

export default function Hero() {
  const sliderImages = [
    "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    "https://images.unsplash.com/photo-1517077304055-6e89abbf09b0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    "https://images.unsplash.com/photo-1629904853893-c2c8981a1dc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
  ];

  return (
    <section className="gradient-bg text-primary-foreground py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl lg:text-6xl font-bold mb-6" data-testid="text-hero-title">
              Full Stack Developer & Technology Enthusiast
            </h1>
            <p className="text-xl mb-8 opacity-90" data-testid="text-hero-description">
              Specializing in MERN Stack, Spring Boot, Python, PHP, and Swift. Building innovative solutions across web and mobile platforms.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/portfolio">
                <button 
                  className="bg-accent text-accent-foreground px-8 py-3 rounded-lg font-semibold hover:shadow-lg smooth-transition"
                  data-testid="button-view-work"
                >
                  View My Work
                </button>
              </Link>
              <Link href="/contact">
                <button 
                  className="border-2 border-accent text-accent px-8 py-3 rounded-lg font-semibold hover:bg-accent hover:text-accent-foreground smooth-transition"
                  data-testid="button-get-in-touch"
                >
                  Get In Touch
                </button>
              </Link>
            </div>
          </div>
          <div className="flex justify-center">
            <div className="w-full max-w-md h-96 shadow-2xl rounded-lg overflow-hidden">
              <ImageSlider 
                images={sliderImages}
                autoPlay={true}
                autoPlayInterval={3500}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
