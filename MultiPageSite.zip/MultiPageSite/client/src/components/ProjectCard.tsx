interface ProjectCardProps {
  image: string;
  title: string;
  description: string;
  technologies: string[];
  type: string;
  index: number;
}

export default function ProjectCard({ 
  image, 
  title, 
  description, 
  technologies, 
  type, 
  index 
}: ProjectCardProps) {
  return (
    <div 
      className="bg-card rounded-lg overflow-hidden shadow-lg card-hover smooth-transition"
      data-testid={`card-project-${index}`}
    >
      <img 
        src={image} 
        alt={title} 
        className="w-full h-48 object-cover"
        data-testid={`img-project-${index}`}
      />
      <div className="p-6">
        <div className="flex items-center mb-3">
          <span 
            className="primary-with-code px-3 py-1 rounded-full text-xs font-semibold"
            data-testid={`badge-project-type-${index}`}
          >
            {type}
          </span>
        </div>
        <h3 className="text-xl font-bold mb-3" data-testid={`text-project-title-${index}`}>
          {title}
        </h3>
        <p className="text-muted-foreground mb-4" data-testid={`text-project-description-${index}`}>
          {description}
        </p>
        <div className="flex flex-wrap gap-2 mb-4">
          {technologies.map((tech, techIndex) => (
            <span 
              key={techIndex}
              className="bg-secondary text-xs px-2 py-1 rounded"
              data-testid={`badge-project-tech-${index}-${techIndex}`}
            >
              {tech}
            </span>
          ))}
        </div>
        <button 
          className="text-primary font-semibold hover:underline"
          data-testid={`button-project-details-${index}`}
        >
          View Details →
        </button>
      </div>
    </div>
  );
}
