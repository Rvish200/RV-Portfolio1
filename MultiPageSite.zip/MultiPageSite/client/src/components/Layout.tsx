import { ReactNode } from "react";
import Navigation from "./Navigation";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>{children}</main>
      <footer className="bg-foreground text-accent py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="bg-primary text-primary-foreground w-10 h-10 rounded-lg flex items-center justify-center font-bold">
                  R
                </div>
                <div className="ml-3">
                  <h3 className="font-bold">Rishabh Vishwakarma</h3>
                  <p className="text-sm opacity-75">Full Stack Developer</p>
                </div>
              </div>
              <p className="text-sm opacity-75 mb-4">
                Passionate about creating innovative solutions across multiple technology stacks and platforms.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2 text-sm">
                <a href="/" className="block hover:text-primary smooth-transition">Home</a>
                <a href="/about" className="block hover:text-primary smooth-transition">About</a>
                <a href="/services" className="block hover:text-primary smooth-transition">Services</a>
                <a href="/portfolio" className="block hover:text-primary smooth-transition">Portfolio</a>
                <a href="/contact" className="block hover:text-primary smooth-transition">Contact</a>
                <a href="/admin" className="block hover:text-primary smooth-transition">Admin</a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Connect With Me</h4>
              <div className="space-y-2 text-sm">
                <p><i className="fas fa-phone mr-2"></i> +91 7803094853</p>
                <p><i className="fas fa-envelope mr-2"></i> rvish230801@gmail.com</p>
              </div>
              <div className="flex space-x-4 mt-6">
                <a href="#" className="bg-primary text-primary-foreground w-10 h-10 rounded-lg flex items-center justify-center hover:shadow-lg smooth-transition">
                  <i className="fab fa-linkedin"></i>
                </a>
                <a href="#" className="bg-primary text-primary-foreground w-10 h-10 rounded-lg flex items-center justify-center hover:shadow-lg smooth-transition">
                  <i className="fab fa-github"></i>
                </a>
                <a href="#" className="bg-primary text-primary-foreground w-10 h-10 rounded-lg flex items-center justify-center hover:shadow-lg smooth-transition">
                  <i className="fab fa-twitter"></i>
                </a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-border mt-8 pt-8 text-center text-sm opacity-75">
            <p>&copy; 2024 Rishabh Vishwakarma. All rights reserved. Built with modern web technologies.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
