import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Phone, Mail, GraduationCap } from "lucide-react";

const contactSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().optional(),
  projectType: z.string().min(1, "Please select a project type"),
  timeline: z.string().min(1, "Please select a timeline"),
  message: z.string().min(10, "Please provide more details about your project")
});

type ContactForm = z.infer<typeof contactSchema>;

export default function Contact() {
  const { toast } = useToast();
  
  const form = useForm<ContactForm>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      projectType: "",
      timeline: "",
      message: ""
    }
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactForm) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Message Sent!",
        description: data.message,
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: ContactForm) => {
    contactMutation.mutate(data);
  };

  return (
    <div className="py-20 bg-card" data-testid="page-contact">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6" data-testid="text-contact-title">
            Get In Touch
          </h1>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto" data-testid="text-contact-description">
            Ready to start your next project? Let's discuss how I can help bring your ideas to life with cutting-edge technology solutions.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <h2 className="text-2xl font-bold mb-8" data-testid="text-contact-info-title">
              Contact Information
            </h2>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4" data-testid="contact-phone">
                <div className="bg-primary text-primary-foreground w-12 h-12 rounded-lg flex items-center justify-center">
                  <Phone className="text-lg" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Phone & WhatsApp</h3>
                  <p className="text-muted-foreground">+91 7803094853</p>
                  <p className="text-sm text-muted-foreground mt-1">Available for calls and WhatsApp messages</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4" data-testid="contact-email">
                <div className="bg-primary text-primary-foreground w-12 h-12 rounded-lg flex items-center justify-center">
                  <Mail className="text-lg" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Email</h3>
                  <p className="text-muted-foreground">rvish230801@gmail.com</p>
                  <p className="text-sm text-muted-foreground mt-1">Professional inquiries and project discussions</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4" data-testid="contact-specialization">
                <div className="bg-primary text-primary-foreground w-12 h-12 rounded-lg flex items-center justify-center">
                  <GraduationCap className="text-lg" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Specialization</h3>
                  <p className="text-muted-foreground">Computer Science & Engineering</p>
                  <p className="text-sm text-muted-foreground mt-1">Full Stack Development & Technology Innovation</p>
                </div>
              </div>
            </div>
            
            {/* Technology Expertise Summary */}
            <div className="mt-12 bg-background p-6 rounded-lg" data-testid="tech-stack-summary">
              <h3 className="font-bold mb-4">Technology Stack</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-semibold mb-2">Backend</p>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• Node.js</li>
                    <li>• Java Spring Boot</li>
                    <li>• Python</li>
                    <li>• PHP</li>
                  </ul>
                </div>
                <div>
                  <p className="font-semibold mb-2">Frontend & Mobile</p>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• React.js</li>
                    <li>• MERN Stack</li>
                    <li>• Swift (iOS)</li>
                    <li>• HTML/CSS/JS</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          
          {/* Contact Form */}
          <div>
            <div className="bg-background p-8 rounded-lg">
              <h2 className="text-2xl font-bold mb-6" data-testid="text-contact-form-title">
                Send a Message
              </h2>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="form-contact">
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="John" 
                              {...field} 
                              data-testid="input-first-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Doe" 
                              {...field} 
                              data-testid="input-last-name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input 
                            type="email" 
                            placeholder="john@example.com" 
                            {...field} 
                            data-testid="input-email"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number (Optional)</FormLabel>
                        <FormControl>
                          <Input 
                            type="tel" 
                            placeholder="+1 (555) 000-0000" 
                            {...field} 
                            data-testid="input-phone"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="projectType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-project-type">
                              <SelectValue placeholder="Select project type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="web-development">Web Application Development</SelectItem>
                            <SelectItem value="mobile-development">Mobile App Development (iOS)</SelectItem>
                            <SelectItem value="backend-development">Backend API Development</SelectItem>
                            <SelectItem value="full-stack">Full Stack Solution</SelectItem>
                            <SelectItem value="legacy-modernization">Legacy System Modernization</SelectItem>
                            <SelectItem value="consulting">Technical Consulting</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="timeline"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Timeline</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger data-testid="select-timeline">
                              <SelectValue placeholder="Select timeline" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="less-than-1-month">Less than 1 month</SelectItem>
                            <SelectItem value="1-3-months">1-3 months</SelectItem>
                            <SelectItem value="3-6-months">3-6 months</SelectItem>
                            <SelectItem value="6-plus-months">6+ months</SelectItem>
                            <SelectItem value="ongoing">Ongoing collaboration</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Project Details</FormLabel>
                        <FormControl>
                          <Textarea 
                            rows={5}
                            placeholder="Tell me about your project requirements, goals, and any specific technologies you'd like to use..."
                            {...field}
                            data-testid="textarea-message"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={contactMutation.isPending}
                    data-testid="button-submit-contact"
                  >
                    {contactMutation.isPending ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
