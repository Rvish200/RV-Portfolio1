import ServiceCard from "@/components/ServiceCard";
import { Globe, Server, Smartphone, Code, Cloud, GraduationCap } from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: <Globe className="text-2xl" />,
      title: "Full Stack Web Development",
      description: "End-to-end web applications using MERN stack, ensuring scalable and maintainable solutions.",
      features: ["React.js Frontend", "Node.js Backend", "MongoDB Database", "RESTful APIs"]
    },
    {
      icon: <Server className="text-2xl" />,
      title: "Enterprise Backend Solutions",
      description: "Robust backend systems with Java Spring Boot and Python for enterprise-grade applications.",
      features: ["Spring Boot Applications", "Python Web Services", "Microservices Architecture", "Database Design"]
    },
    {
      icon: <Smartphone className="text-2xl" />,
      title: "iOS App Development",
      description: "Native iOS applications using Swift, creating seamless experiences for Apple ecosystem users.",
      features: ["Native Swift Development", "UIKit & SwiftUI", "App Store Deployment", "Core Data Integration"]
    },
    {
      icon: <Code className="text-2xl" />,
      title: "Legacy System Modernization",
      description: "Upgrading existing PHP applications and integrating modern technologies for improved performance.",
      features: ["PHP Optimization", "API Integration", "Database Migration", "Performance Tuning"]
    },
    {
      icon: <Cloud className="text-2xl" />,
      title: "Cloud Deployment & DevOps",
      description: "Complete deployment solutions with CI/CD pipelines and cloud infrastructure management.",
      features: ["AWS/Azure Deployment", "Docker Containerization", "CI/CD Pipelines", "Monitoring & Scaling"]
    },
    {
      icon: <GraduationCap className="text-2xl" />,
      title: "Technical Consulting & Training",
      description: "Technical guidance, code reviews, and mentoring for development teams and individuals.",
      features: ["Architecture Planning", "Code Reviews", "Team Mentoring", "Best Practices"]
    }
  ];

  return (
    <div className="py-20 bg-card" data-testid="page-services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6" data-testid="text-services-title">
            Services I Offer
          </h1>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto" data-testid="text-services-description">
            Comprehensive development solutions tailored to your business needs, from concept to deployment
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={index}
              icon={service.icon}
              title={service.title}
              description={service.description}
              features={service.features}
              index={index}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
