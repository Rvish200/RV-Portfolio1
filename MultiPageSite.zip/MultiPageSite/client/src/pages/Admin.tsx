import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Mail, Phone, Calendar, Clock, MessageSquare, User } from "lucide-react";
import type { Contact } from "@shared/schema";

export default function Admin() {
  const { data: contacts, isLoading, error } = useQuery<Contact[]>({
    queryKey: ["/api/contacts"],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8" data-testid="admin-loading">
        <h1 className="text-3xl font-bold mb-8">Admin Panel - Contact Requests</h1>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-40" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="flex space-x-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8" data-testid="admin-error">
        <h1 className="text-3xl font-bold mb-8">Admin Panel - Contact Requests</h1>
        <Card>
          <CardContent className="p-8 text-center">
            <div className="text-red-500 mb-4">
              <MessageSquare className="h-12 w-12 mx-auto" />
            </div>
            <p className="text-lg text-muted-foreground">
              Failed to load contact requests. Please try again later.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getProjectTypeBadgeColor = (type: string) => {
    const colors: Record<string, string> = {
      "Web Development": "bg-blue-100 text-blue-800",
      "Mobile App": "bg-green-100 text-green-800",
      "E-commerce": "bg-purple-100 text-purple-800",
      "Custom Software": "bg-orange-100 text-orange-800",
      "API Development": "bg-cyan-100 text-cyan-800",
      "UI/UX Design": "bg-pink-100 text-pink-800",
    };
    return colors[type] || "bg-gray-100 text-gray-800";
  };

  const getTimelineBadgeColor = (timeline: string) => {
    const colors: Record<string, string> = {
      "1-2 weeks": "bg-red-100 text-red-800",
      "2-4 weeks": "bg-yellow-100 text-yellow-800",
      "1-2 months": "bg-green-100 text-green-800",
      "3+ months": "bg-blue-100 text-blue-800",
    };
    return colors[timeline] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="container mx-auto px-4 py-8" data-testid="admin-panel">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Admin Panel</h1>
        <p className="text-muted-foreground">
          View and manage all contact form submissions
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Contact Requests ({contacts?.length || 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!contacts || contacts.length === 0 ? (
            <div className="text-center py-12" data-testid="no-contacts">
              <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-lg text-muted-foreground">
                No contact requests yet
              </p>
              <p className="text-sm text-muted-foreground">
                Contact submissions will appear here
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Contact Info</TableHead>
                    <TableHead>Project Details</TableHead>
                    <TableHead>Timeline</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Submitted</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contacts.map((contact) => (
                    <TableRow key={contact.id} data-testid={`contact-row-${contact.id}`}>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">
                              {contact.firstName} {contact.lastName}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Mail className="h-3 w-3" />
                            <a 
                              href={`mailto:${contact.email}`}
                              className="hover:text-primary"
                              data-testid={`email-${contact.id}`}
                            >
                              {contact.email}
                            </a>
                          </div>
                          {contact.phone && (
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Phone className="h-3 w-3" />
                              <a 
                                href={`tel:${contact.phone}`}
                                className="hover:text-primary"
                                data-testid={`phone-${contact.id}`}
                              >
                                {contact.phone}
                              </a>
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className={getProjectTypeBadgeColor(contact.projectType)}
                          data-testid={`project-type-${contact.id}`}
                        >
                          {contact.projectType}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className={getTimelineBadgeColor(contact.timeline)}
                          data-testid={`timeline-${contact.id}`}
                        >
                          <Clock className="h-3 w-3 mr-1" />
                          {contact.timeline}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-xs">
                          <p className="text-sm text-muted-foreground truncate" data-testid={`message-${contact.id}`}>
                            {contact.message}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span data-testid={`date-${contact.id}`}>
                            {format(new Date(contact.createdAt), "MMM dd, yyyy 'at' h:mm a")}
                          </span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}