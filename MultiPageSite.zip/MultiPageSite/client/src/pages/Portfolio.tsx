import ProjectCard from "@/components/ProjectCard";

export default function Portfolio() {
  const projects = [
    {
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      title: "E-Commerce Platform",
      description: "Full-featured e-commerce solution with admin dashboard, payment integration, and inventory management.",
      technologies: ["React", "Node.js", "MongoDB", "Stripe"],
      type: "MERN Stack"
    },
    {
      image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      title: "Task Management iOS App",
      description: "Native iOS productivity app with offline sync, push notifications, and collaborative features.",
      technologies: ["Swift", "SwiftUI", "Core Data", "CloudKit"],
      type: "iOS App"
    },
    {
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      title: "HR Management System",
      description: "Enterprise-grade HR platform built with Spring Boot, featuring employee management and analytics.",
      technologies: ["Spring Boot", "Java", "PostgreSQL", "Thymeleaf"],
      type: "Enterprise"
    },
    {
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      title: "Data Analytics Platform",
      description: "Python-powered analytics platform with machine learning capabilities for business intelligence.",
      technologies: ["Python", "Django", "Pandas", "NumPy"],
      type: "Python"
    },
    {
      image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      title: "Social Media Platform",
      description: "Real-time social platform with chat, posts, and multimedia sharing using modern web technologies.",
      technologies: ["React", "Socket.io", "Express", "AWS S3"],
      type: "Full Stack"
    },
    {
      image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      title: "Custom CMS Platform",
      description: "Flexible content management system with multi-site support and advanced SEO optimization.",
      technologies: ["PHP", "Laravel", "MySQL", "Redis"],
      type: "PHP"
    }
  ];

  return (
    <div className="py-20 bg-background" data-testid="page-portfolio">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6" data-testid="text-portfolio-title">
            Featured Projects
          </h1>
          <p className="text-muted-foreground text-lg max-w-3xl mx-auto" data-testid="text-portfolio-description">
            A showcase of diverse projects demonstrating expertise across different technologies and platforms
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard
              key={index}
              image={project.image}
              title={project.title}
              description={project.description}
              technologies={project.technologies}
              type={project.type}
              index={index}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
