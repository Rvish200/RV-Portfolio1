import Hero from "@/components/Hero";
import SkillsOverview from "@/components/SkillsOverview";

export default function Home() {
  return (
    <div data-testid="page-home">
      <Hero />
      <SkillsOverview />
    </div>
  );
}
