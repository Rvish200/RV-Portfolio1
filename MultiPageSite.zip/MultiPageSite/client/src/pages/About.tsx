export default function About() {
  const skills = [
    { name: "MERN Stack", percentage: 95 },
    { name: "Java Spring Boot", percentage: 90 },
    { name: "Python Backend", percentage: 85 },
    { name: "Swift & iOS", percentage: 75 }
  ];

  return (
    <div className="py-20 bg-background" data-testid="page-about">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1533294455009-a77b7557d2d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000" 
              alt="Studio Ghibli inspired creative workspace" 
              className="rounded-lg shadow-xl w-full"
              data-testid="img-about-portrait"
            />
          </div>
          <div>
            <h1 className="text-4xl lg:text-5xl font-bold mb-6" data-testid="text-about-title">
              About Rishabh Vishwakarma
            </h1>
            <div className="space-y-6 text-lg">
              <p data-testid="text-about-intro">
                As a passionate Computer Science and Engineering specialist, I bring comprehensive expertise in full-stack development across multiple technology ecosystems.
              </p>
              <p data-testid="text-about-journey">
                My journey spans from robust backend solutions with <strong>Java Spring Boot</strong> and <strong>Node.js</strong> to modern frontend experiences with the <strong>MERN stack</strong>. I've expanded into <strong>Python backend development</strong> and mobile app creation for the <strong>Apple ecosystem using Swift</strong>.
              </p>
              <p data-testid="text-about-foundation">
                With a foundation in <strong>PHP</strong> and database management, I deliver end-to-end solutions that bridge traditional and cutting-edge technologies.
              </p>
            </div>
            
            {/* Skills Progress Bars */}
            <div className="mt-12 space-y-6">
              {skills.map((skill, index) => (
                <div key={index} data-testid={`skill-progress-${index}`}>
                  <div className="flex justify-between mb-2">
                    <span className="font-semibold" data-testid={`text-skill-name-${index}`}>
                      {skill.name}
                    </span>
                    <span className="text-muted-foreground" data-testid={`text-skill-percentage-${index}`}>
                      {skill.percentage}%
                    </span>
                  </div>
                  <div className="bg-secondary h-2 rounded-full">
                    <div 
                      className="skill-bar h-2 rounded-full" 
                      style={{ width: `${skill.percentage}%` }}
                      data-testid={`bar-skill-progress-${index}`}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
